# Plane Games: third-party source code

Plane Games includes two works licensed under the GNU General Public License.
This archive holds their complete source, as used in the app.

## Stockfish.js 19.0.1 (the chess computer)

- Folder: `stockfish.js-19.0.1/`
- Upstream: https://github.com/nmrugg/stockfish.js (tag `v19.0.1`), based on
  Stockfish, https://github.com/official-stockfish/Stockfish
- Licence: GNU General Public License, version 3 (`stockfish.js-19.0.1/Copying.txt`)
- The app ships `stockfish-19-lite-single.js` and `stockfish-19-lite-single.wasm`
  exactly as published in version 19.0.1 of the `stockfish` package, unmodified.
  It runs as a separate program inside the app and is spoken to only through the
  standard UCI text protocol.
- The neural network file the lite build embeds, `nn-61e7af4bb97d.nnue`, is
  included in `stockfish.js-19.0.1/src/`.
- To rebuild it, follow `stockfish.js-19.0.1/README.md` (`node build.js` with
  Emscripten installed).

## Chess pieces by Colin M.L. Burnett

- Folder: `chess-pieces/`
- Licence: GNU General Public License, version 2 or later (`GPL-2.0.txt`)
- These SVG drawings are their own source. They are included here as used in the app.

## Licence texts

- `GPL-3.0.txt`: GNU General Public License, version 3
- `GPL-2.0.txt`: GNU General Public License, version 2
